#!/usr/bin/env python3
from pathlib import Path
import subprocess, tempfile, sys
root=Path(__file__).resolve().parent
patch=root/'0001-pipa-exp01-schedutil-rate-limit.patch'
content=patch.read_text()
assert content.count('diff --git') in (0,3) # unified patch without git extended header
for x in ('drivers/cpufreq/Kconfig','kernel/sched/cpufreq_schedutil.c','arch/arm64/configs/vendor/pipa_defconfig'):
    assert 'a/'+x in content and 'b/'+x in content
for x in ('CONFIG_PIPA_EXP_SUGOV_RATE_LIMIT_US', 'CONFIG_PIPA_EXP_SUGOV=y', 'tunables->rate_limit_us = 2000;', 'range 1000 2000'):
    assert x in content
assert 'fastboot flash' not in (root/'prepare-build.sh').read_text()
assert '/dev/block' not in (root/'prepare-build.sh').read_text()
subprocess.run(['bash','-n',str(root/'prepare-build.sh')],check=True)
print('PASS: patch structural, safe build script, shell syntax')
