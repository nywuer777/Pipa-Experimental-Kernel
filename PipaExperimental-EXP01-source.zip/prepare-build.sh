#!/usr/bin/env bash
# EXP01 source-first builder. NO FLASHING, NO boot.img construction.
set -euo pipefail

SOURCE_URL="https://github.com/kvsnr113/xiaomi_sm8250_kernel_e404.git"
SOURCE_BRANCH="main-bpf"
SOURCE_SHA="fed88a6024cd4d46c52eda607a95d97d7371ba81"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="${1:-$PWD/pipa-experimental-work}"
MODE="${2:-prepare}"

fail() { printf 'ERRO: %s\n' "$*" >&2; exit 1; }
for tool in git python3; do command -v "$tool" >/dev/null || fail "Falta $tool"; done
mkdir -p "$WORKDIR"
WORKDIR="$(cd "$WORKDIR" && pwd)"
SRC="$WORKDIR/kernel"
if [[ ! -e "$SRC/.git" ]]; then
  git clone --branch "$SOURCE_BRANCH" --single-branch --depth 1 "$SOURCE_URL" "$SRC"
fi
[[ -d "$SRC/.git" ]] || fail "Fonte nao encontrada em $SRC"
cd "$SRC"
HEAD_SHA="$(git rev-parse HEAD)"
[[ "$HEAD_SHA" == "$SOURCE_SHA" ]] || fail "Fonte nao corresponde ao SHA fixado ($SOURCE_SHA), atual=$HEAD_SHA. Nao aplicar patch em fonte diferente."
if git apply --reverse --check "$SCRIPT_DIR/0001-pipa-exp01-schedutil-rate-limit.patch" 2>/dev/null; then
  echo 'Patch EXP01 ja aplicado.'
else
  # Block any *other* local changes before trying to apply the patch.
  if ! git diff --quiet || ! git diff --cached --quiet; then
    fail "Source tree alterada. Use uma copia limpa."
  fi
  if git apply --check "$SCRIPT_DIR/0001-pipa-exp01-schedutil-rate-limit.patch"; then
    git apply "$SCRIPT_DIR/0001-pipa-exp01-schedutil-rate-limit.patch"
    echo 'Patch aplicado.'
  else
    fail 'git apply --check falhou. Nao continuar.'
  fi
fi

if [[ "$MODE" == "prepare" ]]; then
  echo "Fonte alterada: $SRC"
  echo 'Proximo passo: executar modo build em Linux/WSL2 com toolchain adequado.'
  exit 0
fi
[[ "$MODE" == "build" ]] || fail "Modo invalido: $MODE (prepare | build)"
for tool in make clang ld.lld llvm-ar llvm-nm llvm-objcopy bc flex bison; do
  command -v "$tool" >/dev/null || fail "Falta dependencia: $tool"
done
OUT="$WORKDIR/out"
mkdir -p "$OUT"
# The kernel tree's own configuration for pipa, not the older config attached in chat.
make O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 vendor/pipa_defconfig
if ! grep -qx 'CONFIG_PIPA_EXP_SUGOV=y' "$OUT/.config" ||    ! grep -qx 'CONFIG_PIPA_EXP_SUGOV_RATE_LIMIT_US=1500' "$OUT/.config"; then
  fail "Kconfig nao habilitou os parametros EXP01."
fi
# Build only: no deployment or image repacking commands.
make O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 \
    CROSS_COMPILE=aarch64-linux-gnu- CROSS_COMPILE_COMPAT=arm-linux-gnueabi- \
    -j"$(nproc)" 2>&1 | tee "$WORKDIR/build.log"
[[ -s "$OUT/arch/arm64/boot/Image" ]] || fail 'Compilacao terminou sem Image; consulte build.log'
sha256sum "$OUT/arch/arm64/boot/Image" > "$WORKDIR/Image.sha256"
printf 'Image compilada: %s\n' "$OUT/arch/arm64/boot/Image"
printf 'AVISO: Image nao e boot.img e NAO deve ser gravada diretamente em particoes.\n'
