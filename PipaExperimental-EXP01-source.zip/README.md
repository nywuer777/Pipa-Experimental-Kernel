# Pipa Experimental Kernel — EXP01

**Estado:** patch de fonte pronto; **NÃO compilado**, **NÃO validado no hardware**, **NÃO flashável**.

## Alvo

- Xiaomi Pad 6 (`pipa`), Qualcomm SM8250/SD870.
- Android 16, ROM reportada `crDroid 16.0`.
- Referência de fonte: `kvsnr113/xiaomi_sm8250_kernel_e404` branch `main-bpf`, **SHA imutável fixado** `fed88a6024cd4d46c52eda607a95d97d7371ba81` (consulta 2026-10-18).
- Kernel existente: `/proc/version` reportou `4.19.404R`, enquanto `uname -r` reportou `5.10.404R`; não assumir que `uname -r` descreve os headers/ABI verdadeiros.
- Fontes E404 estão sujeitas a **force push**; por isso a identidade de commit é verificada obrigatoriamente.
- O nome do kernel compilado não foi alterado para evitar troca inadvertida do `vermagic`/ABI usado por módulos existentes.

## Experimento de kernel implementado

`CONFIG_PIPA_EXP_SUGOV=y`, `CONFIG_PIPA_EXP_SUGOV_RATE_LIMIT_US=1500`:

- Altera a **taxa inicial de atualização** do governador `schedutil` de 2000us para 1500us (25% menor).
- Aplica-se somente quando compilado com a opção experimental, habilitada aqui **somente em `pipa_defconfig`**.
- Não altera tabelas de clock CPU/GPU, temperatura, tensão, política de energia ou limites `scaling_max_freq`.
- A interface normal `scaling_governor`/`schedutil/rate_limit_us` permanece disponível para recuperar 2000us *em execução*, se suportada pelo sysfs da versão compilada. O valor do defconfig pode ser revertido para `# CONFIG_PIPA_EXP_SUGOV is not set` e recompilado.
- Isto é um **experimento de latência**, não um ganho de FPS demonstrado. Pode inclusive aumentar atividade/consumo e prejudicar autonomia.

## Aplicar a fonte (Linux, WSL2 ou CI)

O script **não instala nada no tablet**. Requer rede GitHub disponível no ambiente que executará o script.

```bash
chmod +x prepare-build.sh
./prepare-build.sh "$HOME/pipa-experiment" prepare
```

O script clona apenas a branch `main-bpf`, **exige commit exato**, usa `git apply --check` e aplica o patch. Se a branch tiver sofrido force-push, falha intencionalmente, sem aplicar a um commit diferente.

Para tentar compilação em ambiente Linux/WSL2 devidamente provisionado com Clang/LLVM, `make`, `bc`, `flex`, `bison`, cross toolchain compatível e bibliotecas requeridas:

```bash
./prepare-build.sh "$HOME/pipa-experiment" build
```

Arquivos gerados esperados: `out/arch/arm64/boot/Image` e `Image.sha256` no diretório de trabalho, após compilação bem-sucedida. **Image não é um boot.img.**

> **Não execute `fastboot flash`, `dd of=/dev/block/...`, nem aplique em AnyKernel3** ainda. Antes da imagem instalável é obrigatório auditar base da ROM, dtb/dtbo, módulos de vendor, root/KernelSU, formato de boot e rollback, testar build e executar check de ABI.

## Validações concluídas nesta entrega

- Inspecionados trechos exatos dos três arquivos upstream, na revisão selecionada, via API GitHub.
- Patch gerado e conferido contra fixtures localmente (teste de conteúdo e aplicação sintética).
- Testes estruturais de script executados (bash -n) e teste de integridade do ZIP.
- **Não** foi obtida uma cópia integral do repositório no ambiente de elaboração (sem conectividade git), então `git apply --check` no tree real e `make` permanecem pendentes.

## Seguimento

1. Preparar código e executar `git apply --check` no commit fixado em ambiente com GitHub acessível.
2. `make ... vendor/pipa_defconfig` e conferir Kconfig.
3. Compilar Image + dtb/dtbo e validar ABI/boot repack com imagens salvas do próprio aparelho (não enviar imagens brutas sem necessidade).
4. Somente após verificações, gerar pacote **específico pipa** de teste e plano de restauração.
